# 101 Okey — Cloudflare Workers

Tek proje, iki mod:

- **Tek başına (çevrimdışı):** her şey tarayıcıda çalışır, sunucuya hiç bağlanmaz.
  `public/index.html` dosyasını çift tıklayıp açsan bile bu mod çalışır.
- **Arkadaşlarla (çevrimiçi):** oda kodu ile 2–4 kişi. Boş koltuklara bot oturur.

## Neden Pages değil Workers?

Cloudflare **Pages, Durable Objects'i desteklemiyor** — gerçek zamanlı oyun odası için
gereken tek şey de o. Workers hem statik dosyayı ücretsiz sunuyor hem de Durable Object
çalıştırıyor. Yani tek `wrangler deploy` ile hem oyun hem sunucu yayına giriyor.

## Mimari

```
tarayıcı ──WebSocket──►  Worker  ──►  Durable Object "OkeyRoom"  (oda başına bir örnek)
   │                        │              ├─ desteyi dağıtır, taşları saklar
   │                        │              ├─ kuralları denetler (kimse hile yapamaz)
   └──── HTTP ─────────────►┘              ├─ boş koltuklarda botu oynatır
        public/index.html                  └─ herkese kendi görebildiği kadarını yollar
```

Her oyuncu **yalnız kendi taşlarını** görür; sunucu herkese kişiselleştirilmiş
durum paketi gönderir (~3 KB).

## Dosyalar

| Dosya | İş |
|---|---|
| `public/index.html` | Oyunun tamamı (arayüz + çevrimdışı motor) |
| `src/worker.js` | Yönlendirme: `/ws/KOD` → oda, `/yeni` → kod üret, gerisi statik |
| `src/room.js` | Durable Object: oda, oyun akışı, kural denetimi, botlar |
| `src/engine.js` | Saf kurallar (per/seri/çift doğrulama, en iyi açılım araması) |
| `wrangler.jsonc` | Cloudflare yapılandırması |

## Yayına alma

```bash
npm install
npx wrangler login          # tarayıcıda Cloudflare hesabına izin ver
npx wrangler deploy
```

Bitince adresin şuna benzer olur:
`https://okey-101.<hesap-adin>.workers.dev`

Yerelde denemek için:

```bash
npm run dev                 # http://localhost:8787
```

Aynı ağdaki telefondan denemek istersen `npx wrangler dev --ip 0.0.0.0` ile çalıştır.

### Kendi alan adın

Cloudflare panelinde **Workers & Pages → okey-101 → Settings → Domains & Routes →
Add custom domain**. Alan adı zaten Cloudflare'daysa TLS otomatik geliyor.

### GitHub'a bağlayıp her push'ta yayınlamak

Panelde **Workers & Pages → Create → Connect to Git**, depoyu seç, derleme komutu boş,
deploy komutu `npx wrangler deploy`.

## Nasıl oynanır (çevrimiçi)

1. Biri **Arkadaşlarla oyna → Oda kur** der, ekranda 4 harfli kod çıkar.
2. Kodu arkadaşlarına gönderir, onlar **Odaya katıl** ile aynı kodu girer.
3. Oda sahibi oyun türünü seçip **Oyunu başlat** der. Boş koltuklara bot oturur.

Bağlantısı kopan oyuncunun yerine bot geçer, oyun durmaz.

## Maliyet

Ücretsiz planda kalıyor: statik dosya istekleri ücretsiz ve sınırsız, Durable Objects
ücretsiz katmanda ayda ~3 milyon istek. Gelen WebSocket mesajları 20:1 oranında
sayılıyor, giden mesajlar ücretsiz. Arkadaş grubuyla oynamak için fazlasıyla yeterli.
